const Publication = require('../models/Publication');

module.exports = class PublicationController{
    
}